import React from 'react';

const AboutUs = () => (
  <div>
    <h2>About UsAbout UsAbout UsAbout UsAbout UsAbout UsAbout UsAbout UsAbout UsAbout UsAbout UsAbout UsAbout UsAbout UsAbout UsAbout UsAbout UsAbout UsAbout UsAbout UsAbout UsAbout UsAbout UsAbout UsAbout UsAbout UsAbout UsAbout UsAbout UsAbout Us</h2>
    {/* Add content for the About Us page */}
  </div>
);

export default AboutUs;
