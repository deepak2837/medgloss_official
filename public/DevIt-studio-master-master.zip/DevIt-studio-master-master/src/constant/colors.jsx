export const backgroundColor = "#FFFFFF";
export const headerColor = "#4E4E50";
export const textColor = "#1E1C31";
