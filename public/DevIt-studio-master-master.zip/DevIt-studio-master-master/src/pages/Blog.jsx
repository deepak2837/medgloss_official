const Blog = () => {
  return <div className=" ">Blog</div>;
};
export default Blog;
