import React from 'react';
import './IconScroll.css'
import { TbArrowsHorizontal } from 'react-icons/tb';
const IconScroll = () => {
  return (
    <div className="tscroll">
    <TbArrowsHorizontal />
    </div>
  )
}

export default IconScroll