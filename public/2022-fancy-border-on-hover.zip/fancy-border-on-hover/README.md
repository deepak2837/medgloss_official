# Fancy border on hover

A Pen created on CodePen.io. Original URL: [https://codepen.io/t_afif/pen/LYeYMBe](https://codepen.io/t_afif/pen/LYeYMBe).

CSS Tip!
https://twitter.com/ChallengesCss/status/1503337056419946497