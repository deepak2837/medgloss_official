# Animated Border Gradient

A Pen created on CodePen.io. Original URL: [https://codepen.io/shshaw/pen/RwJwJJx](https://codepen.io/shshaw/pen/RwJwJJx).

Inspired by the mega buttons on https://turbo.build/

Doesn't truly support border-radius; would need a separate element for that.